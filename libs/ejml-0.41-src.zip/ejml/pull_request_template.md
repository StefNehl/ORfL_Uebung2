Thank you for your contribution to the EJML project.

<!-- Please include a summary of the change and which issue is fixed. 
Please also include relevant motivation and context. List any dependencies that are required for this change. -->

Before submitting this PR, please make sure:
- [ ] Your code is covered by tests
- [ ] You ran `./gradlew spotlessJavaApply`