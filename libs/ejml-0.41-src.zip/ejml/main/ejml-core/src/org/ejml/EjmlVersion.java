package org.ejml;

import javax.annotation.Generated;

/**
 * Automatically generated file containing build version information.
 */
@Generated("com.peterabeles.GVersion")
public final class EjmlVersion {
    public static final String MAVEN_GROUP = "org.ejml";
    public static final String MAVEN_NAME = "autocode";
    public static final String VERSION = "0.41";
    public static final int GIT_REVISION = 956;
    public static final String GIT_SHA = "4658d0edf76059e3a41648129812f384fed51edf";
    public static final String GIT_DATE = "2021-07-07T15:40:46Z";
    public static final String GIT_BRANCH = "HEAD";
    public static final String BUILD_DATE = "2021-07-07T15:45:01Z";
    public static final long BUILD_UNIX_TIME = 1625672701902L;
    public static final int DIRTY = 0;

    private EjmlVersion(){}
}
