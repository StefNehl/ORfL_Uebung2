* LU Determinant
  * Figure out how to compute the determinant's sign on the fly. Got close. Did 10 mc trials before failing
* LU for wide/tall matrices
  * Attempted to add this capability. 
  * Appears to be non-trivial. Will need to go through all the helper algorithms
    and make sure they can handle tall/wide matrices. Unit tests are for now commented out
  * Start by updating triangular solvers